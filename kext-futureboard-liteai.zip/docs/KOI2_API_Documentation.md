# KOI2 驱动库 API 文档

## 概述
koi2是一个人工智能视觉模块，可以用于人脸检测，色块追踪，巡线追踪，扫码识别等功能。

## 函数API

### 1.基础功能

#### 初始化
```python
from koi2 import KOI2

'''
Args:
    uart (str): 串口选择
        可选参数:
            uart0: 串口0
            uart1: 串口1

Returns:
    None
'''
koi2 = KOI2(uart='uart0')
```

#### read_from_uart
更新由koi2发回的串口数据，之后所有获取数据的函数都需要先调用这个函数更新包括按钮状态。

```python
'''
Args:
    None

Returns:
    None
'''
koi2.read_from_uart()
```

#### deinit()
释放串口，一般用户用不到
```python
'''
Args:
    None

Returns:
    None
'''
koi2.deinit()
```

#### setModel()
设置使用模式
```python
'''
Args:
    model (int): 模式选择
        可选参数:
            0x0: 无模式
            0x3: 自定义模型
            0x9: 人脸识别
            0x7: 口罩识别
            0x10: 色块追踪
            0x20: 巡线追踪
            0x5: 特征分类
            0x1: 交通标志
            0x4: 数字识别
            0x6: 字母识别
            0x2: 物体识别
            0x100: 扫码识别

Returns:
    None
'''
koi2.setModel(model=0x0)
```

#### direction()
设置摄像头方向
```python
'''
Args:
    dir (int): 摄像头方向
        可选参数:
            0: 前置
            2: 后置

Returns:
    None
'''
koi2.direction(dir=0)
```

#### mirror()
设置摄像头镜像
```python
'''
Args:
    enabled (bool): 是否启用镜像

Returns:
    None
'''
koi2.mirror(enabled=False)
```

#### getBtnState()
获取按键状态
```python
'''
Args:
    btn (str): 按键名称

Returns:
    bool: 按键状态
'''
koi2.read_from_uart() #此函数需要先更新串口数据
koi2.getBtnState(btn='A')
```

#### recorded()
录音并保存
```python
'''
Args:
    name (str): 保存路径和文件名
    sec (int): 录音时长（秒）

Returns:
    None
'''
koi2.recorded(name='/sd/test.wav',sec=3)
```

#### takePic()
拍照并保存
```python
'''
Args:
    name (str): 保存路径和文件名

Returns:
    None
'''
koi2.takePic(name='/sd/text.jpg')
```

#### displayPic()
将图片显示到koi屏幕
```python
'''
Args:
    path (str): 图片路径和文件名
    millisecond (int): 显示时长（毫秒）

Returns:
    None
'''
koi2.displayPic(path='/sd/test.jpg',millisecond=3000)
```

#### displayText()
在koi屏幕显示文字
```python
'''
Args:
    x (int): x坐标
    y (int): y坐标
    millisecond (int): 显示持续时间（毫秒）
    color (tuple): 颜色，rgb元组，如红色: (255,0,0)
    text (str): 显示的文字内容

Returns:
    None
'''
koi2.displayText(x=40,y=0,millisecond=3000,color=(255,0,0),text='hello')
```
### 2.色块追踪

#### colorSwitch()
在色块追踪模式下(koi2.setModel(0x10))，设置追踪的颜色
```python
'''
Args:
    key (int): 颜色代号
        可选参数:
            0: 红色
            1: 蓝色
            2: 绿色
            3: 黄色
            9: 自定义 #该选项需要配合colorCalibration()使用，重新学习一个新的颜色

Returns:
    None
'''
koi2.colorSwitch(key=0)
```

#### colorCalibration()
当设置的追踪颜色为'自定义时'，可以通过这个函数重新训练追踪色块
```python
'''
Args:
    None

Returns:
    None
'''
koi2.colorCalibration()
```

#### xywh
类属性[x,y,w,h],色块追踪数据会通过read_from_uart()更新后赋值到这里
数据示例,左上角一个20*20的色块:
[0,0,20,20]
```python
koi2.xywh
```

#### 使用示例
```python
from koi2 import KOI2

koi2 = KOI2('uart1')
koi2.setModel(0x10)
koi2.colorSwitch(9)
koi2.colorCalibration()
while True:
  koi2.read_from_uart()
  print(koi2.xywh[0])

```

### 3.线条追踪

#### lineSwitch()
在线条追踪模式下(koi2.setModel(0x20))，设置追踪的颜色
```python
'''
Args:
    key (int): 颜色代号
        可选参数:
            0: 红色
            1: 蓝色
            3: 黄色
            4: 自定义 #该选项需要配合colorCalibration()使用，重新学习一个新的颜色

Returns:
    None
'''
koi2.lineSwitch(key=0)
```

#### colorCalibration()
当设置的追踪颜色为'自定义时'，可以通过这个函数重新训练追踪色块
```python
'''
Args:
    None

Returns:
    None
'''
koi2.colorCalibration()
```

#### xy12
类属性[x1,y1,x2,y2],线条追踪数据会通过read_from_uart()更新后赋值到这里
数据示例,从屏幕左上角开始的一条线:
[0,0,20,20]
```python
koi2.xy12
```

#### 示例
```python
from koi2 import KOI2

koi2 = KOI2('uart1')
koi2.setModel(32)
koi2.lineSwitch(3)
while True:
  koi2.read_from_uart()
  print(koi2.xy12[0])

```

### 4.人脸检测

#### xywh
人脸坐标和大小[x,y,w,h],通过read_from_uart()更新串口数据后赋值到这里

#### getFaceAttr()
获取人脸相关属性
注意事项: 在没有检测到人脸的时候，所有的属性都会返回-1。
所以可以先判断人脸数量是否正常。在获取其他的属性
```python
'''
Args:
    attr (int): 属性代号
        可选参数:
            6: 是否微笑（成立的话返回1否则0）
            7: 是否佩戴眼镜（成立的话返回1否则0）
            5: 是否张嘴（成立的话返回1否则0）
            4: 是否为男性（成立的话返回1否则0）
            8: 人脸数量
            9: 微笑的数量
            12: 戴眼镜的数量
            10: 张嘴的数量
            11: 男性数量
            13: 女性数量

Returns:
    int: 对应的属性值
'''
koi2.getFaceAttr(8)
```

#### 示例
```python
from koi2 import KOI2

koi2 = KOI2('uart1')
koi2.setModel(9)
while True:
  koi2.read_from_uart()
  if int(koi2.getFaceAttr(8)) > 1:
    print(koi2.xywh[0])
```

### 5.人脸口罩检测

#### xywh
[x,y,w,h]检测到的人脸坐标和大小
```python
koi2.xywh[0]
```

#### strVal
返回检测状态
注: 接下来的文档中，可能会有很多strVal，他们确实是同样的函数，只是因为切换模式之后koi启动的视觉模型不同，所以返回的识别结果也不同
```python
'''
Returns:
    str: 检测结果
        可能的返回值:
            with-mask: 戴口罩
            without-mask: 未戴口罩
'''
koi2.strVal
```

#### 示例
```python
from koi2 import KOI2

koi2 = KOI2('uart1')
koi2.setModel(7)
while True:
  koi2.read_from_uart()
  if koi2.xywh[0] > 1:
    if koi2.strVal == 'with-mask':
      print('戴了口罩')
    else:
      print('没戴口罩')
```

### 6.交通标志

#### xywh
[x,y,w,h]检测到的路牌位置和大小
```python
koi2.xywh[0]
```

#### strVal
返回检测状态
```python
'''
Returns:
    str: 交通标志类型
        可能的返回值:
            U-Turn: 掉头
            forward: 直行
            left: 左转
            right: 右转
            limit-30: 限速30
            stop: 停止
            tunnel: 隧道
'''
koi2.strVal
```

#### 示例
```python
from koi2 import KOI2

koi2 = KOI2('uart1')
koi2.setModel(1)
while True:
  koi2.read_from_uart()
  if koi2.xywh[0] > 1:
    if koi2.strVal == 'stop':
      print('检测到停止标志')
```

### 7.物体识别

#### xywh
[x,y,w,h]检测到的物体位置和大小
```python
koi2.xywh[0]
```

#### strVal
返回检测状态
```python
'''
Returns:
    str: 物体类型
        可能的返回值:
            aeroplane: 飞机
            bicycle: 自行车
            bird: 鸟
            boat: 船
            bottle: 瓶子
            bus: 公交车
            car: 汽车
            cat: 猫
            chair: 椅子
            cow: 牛
            diningtable: 餐桌
            dog: 狗
            horse: 马
            motorbike: 摩托车
            person: 人
            pottedplant: 盆栽
            sheep: 羊
            sofa: 沙发
            train: 火车
            tvmonitor: 显示器
'''
koi2.strVal
```

#### 示例
```python
from koi2 import KOI2

koi2 = KOI2('uart1')
koi2.setModel(2)
while True:
  koi2.read_from_uart()
  if koi2.xywh[0] > 1:
    if koi2.strVal == 'person':
      print('检测到人类')
```

### 8.字母识别

#### xywh
[x,y,w,h]检测到的字母位置和大小
```python
koi2.xywh[0]
```

#### strVal
返回检测状态
```python
'''
Returns:
    str: 识别的字母
        可能的返回值:
            A: 字母A
            B: 字母B
            C: 字母C
            D: 字母D
            E: 字母E
            F: 字母F
'''
koi2.strVal
```

#### 示例
```python
from koi2 import KOI2

koi2 = KOI2('uart1')
koi2.setModel(6)
while True:
  koi2.read_from_uart()
  if koi2.xywh[0] > 1:
    if koi2.strVal == 'A':
      print('字母A')
```

### 9.数字识别

#### xywh
[x,y,w,h]检测到的数字位置和大小
```python
koi2.xywh[0]
```

#### numberVal
返回检测状态
```python
'''
Returns:
    int: 识别的数字
        可能的返回值:
            0: 数字0
            1: 数字1
            2: 数字2
            3: 数字3
            4: 数字4
            5: 数字5
            6: 数字6
            7: 数字7
            8: 数字8
            9: 数字9
'''
koi2.numberVal
```

#### 示例
```python
from koi2 import KOI2

koi2 = KOI2('uart1')
koi2.setModel(4)
while True:
  koi2.read_from_uart()
  if koi2.xywh[0] > 1:
    if koi2.numberVal == 1:
      print('数字1')
```

### 11.扫码

#### scanCodeSwitchType
设置扫码类型
```python
'''
Args:
    type (int): 扫码类型
        可选参数:
            0: 二维码
            1: 条形码

Returns:
    None
'''
koi2.scanCodeSwitchType(type=0)
```

#### xywh
[x,y,w,h]检测到的图码位置和大小
```python
koi2.xywh[0]
```

#### strVal
返回图码内容
```python
'''
Returns:
    str: 扫码结果内容
'''
koi2.strVal
```
#### 示例
```python
from koi2 import KOI2
koi2 = KOI2('uart1')
koi2.setModel(256)
koi2.scanCodeSwitchType(0)
while True:
  koi2.read_from_uart()
  print(koi2.strVal)

```

### 12.特征分类
将摄像头当前的整体画面进行即时的学习或者识别

#### classifierAddTag
将当前摄像头画面学习到指定的分类
```python
'''
Args:
    tag (str): 分类标签名称
        注意: 不要包含空格

Returns:
    None
'''
koi2.classifierAddTag(tag='A')
```

#### strVal
特征分类识别结果(如果从未进行训练，那么就会返回None)
```python
'''
Returns:
    str: 识别结果
        说明: 会返回用classifierAddTag()学习时对应的tag
'''
koi2.strVal
```

#### classifierReset
清空之前用classifierAddTag学习的数据
```python
'''
Args:
    None

Returns:
    None
'''
koi2.classifierReset()
```

#### classifierSave
保存训练数据
```python
'''
Args:
    name (str): 保存的路径和文件名

Returns:
    None
'''
koi2.classifierSave(name='/sd/data.json')

```

#### classifierLoad
加载训练数据
```python
'''
Args:
    name (str): 读取的路径和文件名

Returns:
    None
'''
koi2.classifierLoad(name='/sd/data.json')
```

#### 示例
```python
'''
由于该模式流程相较于其他模式比较复杂，所以需要用到其他模块的输入检测。示例中使用了按键输入来触发学习。
在学习数据之后，串口会打印相似度最高的结果。
'''
from future import *
from sensor import Sensor
from koi2 import KOI2

sensors = Sensor()

koi = KOI2('uart1')
koi.setModel(5)
while True:
  if sensors.btnValue('a'):
    koi.classifierAddTag('A')
    sleep(0.2)
  if sensors.btnValue('b'):
    koi.classifierAddTag('B')
    sleep(0.2)
  koi.read_from_uart()
  print(koi.strVal)
```
