# PMSA003I PM传感器模块
简介：用于测量PM1.0、PM2.5、PM10颗粒物浓度，支持标准颗粒物和大气环境两种模式
```python
from pmsa003i import PMSA003I
from future import *
import time

# 初始化PM传感器
pm_sensor = PMSA003I()              # 通过I2C接口通信，地址0x12
                                    # 自动初始化传感器

# 读取PM数据
pm_data = pm_sensor.read()          # 返回值: 包含6个PM值的列表
                                    # [PM1.0_CF1, PM2.5_CF1, PM10_CF1, PM1.0_ATM, PM2.5_ATM, PM10_ATM]
                                    # CF1: 标准颗粒物浓度 (μg/m³)
                                    # ATM: 大气环境下浓度 (μg/m³)

# 典型使用示例
while True:
    data = pm_sensor.read()
    
    # 标准颗粒物浓度 (CF=1)
    pm1_0_cf1 = data[0]    # PM1.0 标准颗粒物
    pm2_5_cf1 = data[1]    # PM2.5 标准颗粒物  
    pm10_cf1 = data[2]     # PM10 标准颗粒物
    
    # 大气环境下浓度
    pm1_0_atm = data[3]    # PM1.0 大气环境
    pm2_5_atm = data[4]    # PM2.5 大气环境
    pm10_atm = data[5]     # PM10 大气环境
    
    print("=== 标准颗粒物浓度 (CF=1) ===")
    print(f"PM1.0: {pm1_0_cf1} μg/m³")
    print(f"PM2.5: {pm2_5_cf1} μg/m³") 
    print(f"PM10:  {pm10_cf1} μg/m³")
    
    print("=== 大气环境下浓度 ===")
    print(f"PM1.0: {pm1_0_atm} μg/m³")
    print(f"PM2.5: {pm2_5_atm} μg/m³")
    print(f"PM10:  {pm10_atm} μg/m³")
    
    # PM2.5空气质量等级判断 (基于大气环境值)
    if pm2_5_atm <= 35:
        air_quality = "优良"
    elif pm2_5_atm <= 75:
        air_quality = "轻度污染"
    elif pm2_5_atm <= 115:
        air_quality = "中度污染"
    elif pm2_5_atm <= 150:
        air_quality = "重度污染"
    else:
        air_quality = "严重污染"
    
    print(f"空气质量: {air_quality}")
    print("-" * 30)
    
    time.sleep(2)
```

**使用说明：**
- PM传感器通过I2C接口通信，地址为0x12
- read()方法返回6个PM值的列表，包含两种测量模式
- CF=1标准颗粒物：适用于对比不同传感器的测量结果
- 大气环境下浓度：更接近实际环境中的颗粒物浓度
- 建议使用大气环境值进行空气质量评估
- 数据校验失败时返回上次有效数据，确保程序稳定运行 