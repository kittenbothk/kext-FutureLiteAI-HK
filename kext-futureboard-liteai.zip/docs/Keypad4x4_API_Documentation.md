# 4x4键盘模块 API文档

## 概述

4x4键盘模块提供16个按键的输入检测功能，支持数字0-9、字母A-D以及*、#特殊符号。

## 快速开始

```python
from keypad4x4 import Keypad

# 创建键盘实例
keypad = Keypad('uart1')

while True:
    # 读取按键
    key = keypad.read()
    
    if key is not None:
        print(f"按下了: {key}")
```

## API详细说明

### 类：Keypad(port, inputs=16)

创建4x4键盘操作实例。

**参数：**
- `port` (string): UART接口名称
  - `"uart0"`: 使用引脚43(SDO), 44(SCL)
  - `"uart1"`: 使用引脚17(SDO), 18(SCL)
- `inputs` (int): 输入数量，默认为16

**键位映射：**
```
1  2  3  A
4  5  6  B  
7  8  9  C
*  0  #  D
```

**示例：**
```python
# 使用uart1接口
keypad = Keypad('uart1')

# 使用uart0接口
keypad = Keypad('uart0')
```

### 方法

#### read()

读取当前按下的按键。

**返回值：**
- **类型：** `string` 或 `None`
- **说明：** 返回按键字符`"0"-"9"`, `"A"-"D"`, `"*"`, `"#"`，无按键时返回`None`

**示例：**
```python
key = keypad.read()

if key is not None:
    print(f"检测到按键: {key}")
else:
    print("没有按键按下")
```