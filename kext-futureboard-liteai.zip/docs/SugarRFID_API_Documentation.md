### 方糖RFID模块
简介：用于做智能门禁项目或者图书借阅系统等需要
```python
from rfid import *
from future import *
from sensor import Sensor

# 初始化RFID模块
rfids = RFID()                 # 无需指定端口，使用I2C接口
sensors = Sensor()

# 检测RFID卡
if rfids.scan()[0] == 0:      # 返回值: 0(检测到卡) / 1(未检测到卡)
    
    # 写入数据到指定块
    rfids.write(block, data)   # block: 块号 (0-46)
                               # data: 要写入的数据字符串
                               # 例如: rfids.write(0, 'hello kittenbot')
    
    # 读取卡的UUID（卡号）
    card_uuid = rfids.uuid()   # 返回值: 卡的唯一标识符
    
    # 读取指定块的数据
    block_data = rfids.read(block) # block: 块号 (0-46)
                                   # 返回值: 块中存储的数据字符串
                                   # 例如: rfids.read(46)
```

**使用说明：**
- RFID模块通过I2C总线通信，无需指定P1-P4端口
- 读取和写入前，先检测RFID卡的存在
- 可以读取和写入数据到指定的数据块
- 每个RFID卡都有唯一的UUID标识
- 数据块编号范围：0-46
- 写入数据不能超过20个字符，如果超过后，请写到下一个块中。