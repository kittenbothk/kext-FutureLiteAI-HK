# 方糖CO2模块
简介：用于测量二氧化碳浓度、环境温度和相对湿度，基于SCD4X传感器
```python
from sugar_co2 import Sugarco2
from future import *
import time

# 初始化CO2传感器
co2_sensor = Sugarco2()              # i2c_addr参数: 默认0x62，通过I2C接口通信
                                     # 自动执行初始化设置（温度补偿4.0°C，海拔540m）

# 传感器控制
co2_sensor.begin                     # 停止周期性测量（用于初始化）
                                     # 返回值: True(成功) / False(失败)

co2_sensor.enable_period_measure(0x21b1)  # mode参数: 启动/停止周期性测量
                                          # 0x21b1: 开始周期测量(5秒间隔)
                                          # 0x3f86: 停止周期测量

# 数据读取（方式一：单独获取）
co2_ppm = co2_sensor.CO2             # 获取CO2浓度，单位ppm
temp = co2_sensor.temperature        # 获取环境温度，单位摄氏度
humidity = co2_sensor.relative_humidity  # 获取相对湿度，单位%RH

# 数据读取（方式二：批量获取）
co2_ppm, temp, humidity = co2_sensor.read_measurement  # 返回值: (CO2浓度, 温度, 湿度)
                                                       # 自动检查数据就绪状态

# 数据就绪状态检查
if co2_sensor.get_data_ready_status:     # 返回值: True(数据就绪) / False(数据未就绪)
    print("传感器数据就绪")

# 传感器设置
co2_sensor.set_temp_comp(4.0)           # temp_comp: 温度补偿值(摄氏度)
temp_comp = co2_sensor.get_temp_comp     # 获取当前温度补偿值

co2_sensor.set_sensor_altitude(540)     # altitude: 海拔高度(米)
altitude = co2_sensor.get_sensor_altitude # 获取当前设置的海拔高度

co2_sensor.set_ambient_pressure(1013.25) # ambient_pressure: 环境气压(hPa)

# 校准功能
co2_sensor.set_auto_calib_mode(True)     # mode: True(启用自动校准) / False(禁用)
auto_calib = co2_sensor.get_auto_calib_mode  # 获取自动校准状态

result = co2_sensor.perform_forced_recalibration(400)  # CO2ppm: 已知CO2浓度值
                                                       # 返回值: 校准结果

# 低功耗模式
co2_sensor.set_sleep_mode(0x36e0)        # mode参数: 0x36e0(进入睡眠) / 0x36f6(唤醒)
co2_sensor.measure_single_shot(0x219d)   # mode参数: 单次测量模式
                                         # 0x219d: 完整测量 / 0x2196: 仅温湿度

# 高级功能
co2_sensor.persist_settings             # 保存当前设置到传感器
self_test = co2_sensor.perform_self_test # 执行自检，返回测试结果
co2_sensor.perform_factory_reset        # 恢复出厂设置
co2_sensor.module_reinit                # 重新初始化模块
 
# 典型使用示例
while True:
    co2_ppm, temp, humidity = co2_sensor.read_measurement
    print(f"CO2浓度: {co2_ppm} ppm")
    print(f"环境温度: {temp:.2f} °C")  
    print(f"相对湿度: {humidity:.2f} %RH")
    time.sleep(5)  # 建议间隔5秒以上
```

**使用说明：**
- CO2模块通过I2C接口通信，地址为0x62
- 支持CO2浓度(ppm)、温度(°C)、湿度(%RH)三种数据测量
- 周期性测量模式更新间隔为5秒，低功耗模式约30秒
- 建议在通风良好的环境中进行校准
- 温度补偿和海拔设置可提高测量精度
- 单次测量模式适用于低功耗应用场景 