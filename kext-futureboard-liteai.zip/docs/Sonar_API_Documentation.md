# 猫头超声波传感器驱动库 API 文档

## 概述
猫头超声波传感器库提供了单引脚超声波传感器的驱动支持。可以用于距离测量、障碍物检测等功能。

## 函数API

### 1. 猫头超声波传感器

#### 初始化
```python
from sonar import MeowSonar

'''
Args:
    pin (str): 信号引脚
        可选参数:
            P1: 端口P1
            P2: 端口P2
            P3: 端口P3
            P4: 端口P4
    
    timeout (int): 超时时间（微秒），默认30000
        说明: 测量超时时间，超过此时间未收到回响信号则抛出异常

Returns:
    None
'''
meow_sonar = MeowSonar(pin='P1', timeout=30000)
```

#### checkdist()
测量距离
```python
'''
Args:
    unit (str): 距离单位，默认'cm'
        可选参数:
            'cm' 或 '厘米': 厘米
            'mm' 或 '毫米': 毫米

Returns:
    int: 测量距离值
        说明: 
            - 正常范围内返回实际距离值
            - 距离值已四舍五入到整数

Raises:
    OSError: 当超出测量范围时抛出 'Out of range' 异常
'''
distance = meow_sonar.checkdist(unit='cm')
```

#### 使用示例
```python
from sonar import MeowSonar
import time

# 初始化猫头超声波传感器
meow_sonar = MeowSonar(pin='P1')

while True:
    try:
        # 测量距离
        distance = meow_sonar.checkdist('cm')
        print('距离:', distance, '厘米')
        
        # 检测障碍物（距离小于20厘米）
        if distance < 20:
            print('检测到障碍物！')
        else:
            print('前方通畅')
            
    except OSError as e:
        if str(e) == 'Out of range':
            print('超出测量范围')
        else:
            print('传感器错误:', e)
    
    time.sleep(0.1)
```