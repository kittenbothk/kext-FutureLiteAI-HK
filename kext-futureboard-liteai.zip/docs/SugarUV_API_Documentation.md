# 方糖UV模块
简介：用于测量紫外线指数(UVI)和光照强度(LUX)，基于LTR390传感器
```python
from sugar_UV import LTR390
from future import *
import time

# 初始化UV传感器
uv_sensor = LTR390()                # address参数: 默认0x53，通过I2C接口通信
                                    # 自动检测存储芯片并加载校准数据

# 获取紫外线指数
uvi_value = uv_sensor.uvi           # 返回值: 紫外线指数(整数)
                                    # 0-2(低), 3-5(中等), 6-7(高), 8-10(很高), 11+(极高)

# 获取光照强度  
lux_value = uv_sensor.lux           # 返回值: 光照强度(整数，单位lux)
                                    # 典型值: 室内100-500, 阴天1000, 晴天10000+

# 校准传感器
uv_sensor.calibration(350, 2500)   # uv参数: 标准紫外线指数参考值(默认350)
                                    # lux参数: 标准光照强度参考值(默认2500)
                                    # 在已知标准光源下进行校准，提高测量精度
                                    # 校准数据自动保存到存储芯片(如果存在)

# 典型使用示例
while True:
    uvi = uv_sensor.uvi
    lux = uv_sensor.lux
    
    print(f"紫外线指数: {uvi}")
    
    # UV指数等级判断
    if uvi <= 2:
        uv_level = "低"
    elif uvi <= 5:
        uv_level = "中等" 
    elif uv_level <= 7:
        uv_level = "高"
    elif uvi <= 10:
        uv_level = "很高"
    else:
        uv_level = "极高"
    
    print(f"UV等级: {uv_level}")
    print(f"光照强度: {lux} lux")
    
    time.sleep(1)
```

**使用说明：**
- UV模块通过I2C接口通信，地址为0x53
- 支持UVI(紫外线指数)和LUX(光照强度)两种数据测量
- 内置缓存机制，避免频繁读取传感器数据
- 校准功能可提高测量精度，需在标准光源环境下进行
- 如检测到存储芯片，校准数据会自动保存和加载
- 建议在室外或有紫外光源的环境中使用校准功能 