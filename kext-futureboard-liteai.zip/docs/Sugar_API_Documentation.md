# 方糖基础模块驱动库 API 文档

## 目录
- [概述](#概述)
- [引脚说明](#引脚说明)
- [数字输出模块](#数字输出模块)
- [数字输入模块](#数字输入模块)
- [模拟输入模块](#模拟输入模块)
- [I2C协议模块](#i2c协议模块)
- [数字协议模块](#数字协议模块)

---

## 概述

方糖系列模块的基础模块部分，支持数字输入输出、模拟输入和PWM功能。本文档详细介绍了各模块的使用方法和API接口。

---

## 引脚说明

| 引脚类型 | 引脚编号 | 支持功能 | 说明 |
|---------|---------|----------|------|
| 通用引脚 | P1~P4 | 数字I/O、PWM、ADC | 可用于连接各类传感器和执行器 |
| 串口引脚 | uart0~uart1 | 串口通信 | 专用于串口模块通信 |

---

## 数字输出模块

### 方糖LED模块
**功能说明：** 数字输出类型，控制LED灯的开关状态

```python
from sugar import *

# 创建LED对象
led_p1 = LED('P1')

# 控制LED状态
led_p1.state('OFF')  # 关闭LED
led_p1.state('ON')   # 打开LED
```

**参数说明：**
- `state()`：设置LED状态
  - `'ON'`：打开LED
  - `'OFF'`：关闭LED

---

### 方糖有源蜂鸣器模块
**功能说明：** 数字输出类型，通过高低电平播放固定频率的鸣叫

```python
from sugar import *

# 创建蜂鸣器对象
buzzerA_p1 = BuzzerA('P1')

# 控制蜂鸣器
buzzerA_p1.state(1)  # 开启蜂鸣器
buzzerA_p1.state(0)  # 关闭蜂鸣器
```

**参数说明：**
- `state(value)`：控制蜂鸣器状态
  - `1`：开启
  - `0`：关闭

---

### 方糖红点激光模块
**功能说明：** 数字输出类型，红点镭射激光，可用于智能防盗系统或逗猫器等应用

```python
from sugar import *

# 创建激光模块对象
laser_p1 = Laser('P1')

# 控制激光器
laser_p1.state(1)  # 打开激光
laser_p1.state(0)  # 关闭激光
```

**安全提示：** ⚠️ 请勿直视激光，避免对眼睛造成伤害

---

### 方糖雾化传感器
**功能说明：** 将水雾化，增加空气湿度

```python
from sugar import *

# 创建雾化器对象
fogging_p1 = Fogging('P1')

# 控制雾化器
fogging_p1.state(1)  # 开启雾化
fogging_p1.state(0)  # 关闭雾化
```

---

### 方糖振动模块
**功能说明：** 数字输出类型，振动马达，提供触感反馈，适用于模拟竞技类反馈效果

```python
from sugar import *

# 创建振动模块对象
vibrate_p1 = Vibrate('P1')

# 控制振动
vibrate_p1.state(1)  # 开启振动
vibrate_p1.state(0)  # 关闭振动
```

---

## 数字输入模块

### 方糖碰撞模块
**功能说明：** 数字输入类型，具有合适的杠杆力臂设计，使按键能够被更轻的力量触发

```python
from sugar import *

# 创建碰撞检测对象
crash_p1 = Crash('P1')

# 检测碰撞状态
if crash_p1.value():
    print("检测到碰撞！")
```

**返回值：**
- `True`：检测到碰撞
- `False`：未检测到碰撞

---

### 方糖触摸模块
**功能说明：** 数字输入类型，电容式触摸检测，只能被人体触发，有效防止物理误触

```python
from sugar import *

# 创建触摸检测对象
touch_p1 = Touch('P1')

# 检测触摸状态
if touch_p1.value():
    print("检测到触摸！")
```

**特点：** 仅对人体触摸敏感，抗干扰能力强

---

### 方糖按键模块
**功能说明：** 数字输入类型，物理按键检测，常用于开关量切换或计数

```python
from sugar import *

# 创建按键对象
button_p1 = Button('P1')

# 检测按键状态
if button_p1.value() == 0:
    print("按键被按下！")
```

**返回值：**
- `0`：按键被按下
- `1`：按键未被按下

---

### 方糖PIR模块
**功能说明：** 数字输入类型，通过检测生物红外波动，确定一定距离内是否有生物运动

```python
from sugar import *

# 创建PIR检测对象
pir_p1 = PIR('P1')

# 检测人体移动
if pir_p1.value():
    print("检测到生物移动！")
```

**应用场景：** 自动照明、安防监控、节能控制

---

### 方糖巡线模块
**功能说明：** 数字输入类型，用于黑色巡线场景，建议使用2个及以上配套使用

```python
from sugar import *

# 创建巡线检测对象
tracker_p1 = Tracker('P1')

# 检测黑线
if tracker_p1.value() == 0:
    print("检测到黑线！")
```

**使用建议：** 多个传感器配合使用效果更佳

---

### 方糖霍尔模块
**功能说明：** 数字输入类型，检测磁性物质，能够分别检测南极或北极磁性

```python
from sugar import *

# 创建霍尔检测对象
hall_p1 = Hall('P1')

# 检测磁性物质
if hall_p1.value() == 0:
    print("检测到磁性物质！")
```

**应用场景：** 保险箱、门锁、位置检测

---

## 模拟输入模块

### 方糖光敏模块
**功能说明：** 模拟输入类型，通过模拟值反馈环境光线强度

```python
from sugar import *

# 创建光敏检测对象
light_p1 = Light('P1')

# 读取光线强度
light_value = light_p1.value()
print(f"当前光线强度：{light_value}")
```

**返回值：** 0-1023范围的整数，数值越大表示光线越强

---

### 方糖火焰模块
**功能说明：** 模拟输入类型，检测火焰或760-1100nm波长光源

```python
from sugar import *

# 创建火焰检测对象
flame_p1 = Flame('P1')

# 读取火焰强度
flame_value = flame_p1.value()
print(f"火焰检测值：{flame_value}")
```

**检测范围：** 打火机测试距离约80cm，火焰越大检测距离越远

---

### 方糖电位器模块
**功能说明：** 模拟输入类型，270度可旋转角度，输出0V到供电电压

```python
from sugar import *

# 创建电位器对象
angle_p1 = Angle('P1')

# 读取角度值
angle_value = angle_p1.value()
print(f"当前角度值：{angle_value}")
```

**旋转范围：** 270度，适用于控制类项目

---

### 方糖声音强度模块
**功能说明：** 模拟输入类型，高灵敏度声音强度检测

```python
from sugar import *

# 创建声音检测对象
sound_p1 = Sound('P1')

# 读取声音强度
sound_value = sound_p1.value()
print(f"声音强度：{sound_value}")
```

**特点：** 检测灵敏度高，响应速度快

---

### 方糖灰度模块
**功能说明：** 模拟输入类型，自发光探测，抗环境光干扰

```python
from sugar import *

# 创建灰度检测对象
grayscale_p1 = Grayscale('P1')

# 读取灰度值
gray_value = grayscale_p1.value()
print(f"灰度值：{gray_value}")
```

**优势：** 能准确区分不同颜色的灰度数据

---

### 方糖土壤湿度模块
**功能说明：** 模拟输入类型，检测土壤湿度，适用于智能浇花项目

```python
from sugar import *

# 创建土壤湿度检测对象
soil_p1 = Soil('P1')

# 读取土壤湿度
soil_value = soil_p1.value()
print(f"土壤湿度：{soil_value}")
```

**使用方法：** 将传感器探头插入土壤，确保紧密接触

---

### 方糖雨滴水位模块
**功能说明：** 模拟输入类型，检测液体存在，快速响应水位变化

```python
from sugar import *

# 创建水位检测对象
waterLevel_p1 = WaterLevel('P1')

# 读取水位
water_value = waterLevel_p1.value()
print(f"水位值：{water_value}")
```

**应用场景：** 智能晾衣、雨水检测、水位监控

---

## I2C协议模块

### 方糖激光测距模块
**功能说明：** I2C类型，TOF激光测距，具有更小的扩散角度

```python
from sugar import *

# 创建测距对象
tofDis = TOFDistance()

# 读取距离
distance = tofDis.value()
print(f"测量距离：{distance}mm")
```

**优势：** 相比超声波具有更高精度和更小扩散角

---

### 方糖五向摇杆模块
**功能说明：** I2C类型，提供X/Y坐标和按键功能

```python
from sugar import *

# 创建摇杆对象
joystick = Joystick()

# 获取摇杆状态
state = joystick.state()
print(f"摇杆状态：{state}")

# 获取X轴坐标
x_value = joystick.value('x')
print(f"X轴坐标：{x_value}")

# 获取Y轴坐标
y_value = joystick.value('y')
print(f"Y轴坐标：{y_value}")
```

**返回值说明：**
- `state()`：返回字符串类型，可能值为 `up`、`down`、`left`、`right`、`pressed`
- `value(axis)`：返回坐标值，范围-255~255，0表示正中间

---

### 方糖温湿度模块
**功能说明：** I2C类型，高精度温湿度检测

```python
from sugar import *

# 创建温湿度检测对象
env1 = ENV()

# 读取温湿度数据
data = env1.update()
temp = data[0]  # 温度
hum = data[1]   # 湿度

print(f"温度：{temp}°C")
print(f"湿度：{hum}%")
```

**返回值：** 返回包含温度和湿度的元组 `(温度, 湿度)`

---

### 方糖气压模块
**功能说明：** I2C类型，提供气压、海拔和温度数据

```python
from sugar import *

# 创建气压检测对象
env2 = ENV2()

# 读取气压（百帕）
pressure = env2.read_pres()
print(f"气压：{pressure} hPa")

# 读取海拔高度（米）
altitude = env2.read_altitude()
print(f"海拔：{altitude} m")

# 读取温度
temp_data = env2.read_temp()
celsius = temp_data[0]    # 摄氏度
fahrenheit = temp_data[1] # 华氏度
print(f"温度：{celsius}°C / {fahrenheit}°F")
```

**功能列表：**
- `read_pres()`：返回气压值（百帕）
- `read_altitude()`：返回海拔高度（米）
- `read_temp()`：返回温度元组（摄氏度，华氏度）

---

### 方糖数码管模块
**功能说明：** I2C类型，4位数码管显示，支持数字、小数点和冒号显示

```python
from sugar import *

# 创建数码管对象
display = Nixietube()

# 显示四位数字
display.shownum(1234)

# 在指定位置显示内容
display.showbit(1, 0)  # 在第0位显示数字1

# 设置小数点或冒号
display.showDP(0, True)   # 点亮第0位小数点
display.showDP(1, True)   # 点亮冒号（第1位特殊）

# 设置亮度
display.intensity(8)  # 设置最高亮度

# 清屏
display.clear()
```

**API详细说明：**

| 方法 | 参数 | 功能 |
|------|------|------|
| `shownum(num)` | `num`: 要显示的数字 | 显示四位数字 |
| `showbit(content, position)` | `content`: 显示内容<br>`position`: 位置(0-3) | 在指定位置显示指定内容 |
| `showDP(position, state)` | `position`: 位置(0-3)<br>`state`: 开关状态 | 控制小数点/冒号显示 |
| `intensity(level)` | `level`: 亮度等级(0-8) | 设置数码管亮度 |
| `clear()` | 无 | 清除显示内容 |

**注意事项：**
- 位置参数从0开始计数
- 位置1控制冒号，其他位置控制小数点
- 亮度范围0-8，8为最亮

---

## 数字协议模块

### 方糖红外接收模块
**功能说明：** 数字协议类型，解析红外遥控器信号

```python
from sugar import *

# 创建红外接收对象
infra_p1 = InfraRx('P1')

# 获取红外数据
ir_code = infra_p1.getInfraRxData()
print(f"接收到红外码：{ir_code}")
```

**返回值：** 字符串形式的十六进制数据

---

### 方糖水温模块
**功能说明：** 数字协议类型，防水温度检测，适用于液体温度测量

```python
from sugar import *

# 创建水温检测对象
ds1 = UDS18X20('P1')

# 读取温度
temperature = ds1.temperature
print(f"水温：{temperature}°C")
```

**特点：** 防水设计，可直接插入液体中使用

---

## 总结

本文档涵盖了方糖基础模块的所有API接口，按功能类型进行分类：

- **数字输出模块**：LED、蜂鸣器、激光、雾化器、振动器
- **数字输入模块**：碰撞、触摸、按键、PIR、巡线、霍尔传感器
- **模拟输入模块**：光敏、火焰、电位器、声音、灰度、土壤湿度、水位传感器
- **I2C协议模块**：激光测距、摇杆、温湿度、气压、数码管
- **数字协议模块**：红外接收、水温传感器

所有模块均支持统一的引脚配置和简洁的API调用方式，便于快速开发和原型制作。

---

*更新日期：2024年*

