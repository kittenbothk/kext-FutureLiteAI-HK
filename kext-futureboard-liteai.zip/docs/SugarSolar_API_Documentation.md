# 方糖太阳能电源管理模块
简介：用于电源管理、电池电量监测、RTC时钟和定时关机功能
```python
from sugar_solar import *
from future import *
import time

# 初始化太阳能电源管理模块
solar = Solar()                     # 通过I2C接口通信，地址37
                                    # 自动检测模块连接状态

# 电源控制
solar.set_power(1)                  # val参数: 1(开启电源) / 0(关闭电源)
                                    # 控制系统电源开关状态

# 获取电池电量
battery_level = solar.battery_level() # 返回值: 电池电压(浮点数，单位V)
                                       # 典型值: 3.0-4.2V (锂电池)

# 读取RTC时间
rtc_time = solar.read_rtc()         # 返回值: (年, 月, 日, 时, 分, 秒)
year = solar.read_rtc()[0]          # 获取年份
month = solar.read_rtc()[1]         # 获取月份
day = solar.read_rtc()[2]           # 获取日期
hour = solar.read_rtc()[3]          # 获取小时
minute = solar.read_rtc()[4]        # 获取分钟
second = solar.read_rtc()[5]        # 获取秒钟

# 设置RTC时间
solar.set_rtc(2024, 6, 6, 15, 45, 30) # 参数: 年, 月, 日, 时, 分, 秒
                                       # 年份支持大于2000的完整年份
                                       # 设置硬件实时时钟

# 设置定时关机
solar.set_alarm(15, 48, 30, down=1) # 参数: 时, 分, 秒, down标志
                                     # down=1: 到时关机, down=0: 到时开机
                                     # 在指定时间执行电源操作

# 典型使用示例 - 太阳能定时系统
print("初始化太阳能电源管理系统...")

# 检查电池电量
voltage = solar.battery_level()
print(f"当前电池电压: {voltage:.2f}V")

if voltage < 3.3:
    print("电池电量过低，建议充电")
elif voltage > 4.0:
    print("电池电量充足")
else:
    print("电池电量正常")

# 设置当前时间
solar.set_rtc(2024, 6, 6, 15, 45, 30)
print("RTC时间已设置")

# 读取并显示当前时间
year, month, day, hour, minute, second = solar.read_rtc()
print(f"当前时间: {year}-{month:02d}-{day:02d} {hour:02d}:{minute:02d}:{second:02d}")

# 设置定时关机 (30分钟后关机)
shutdown_hour = hour
shutdown_minute = minute + 30
if shutdown_minute >= 60:
    shutdown_minute -= 60
    shutdown_hour += 1
if shutdown_hour >= 24:
    shutdown_hour -= 24

solar.set_alarm(shutdown_hour, shutdown_minute, 0, down=1)
print(f"定时关机已设置: {shutdown_hour:02d}:{shutdown_minute:02d}:00")

# 启用电源
solar.set_power(1)
print("系统电源已启用")

# 监控循环
while True:
    voltage = solar.battery_level()
    year, month, day, hour, minute, second = solar.read_rtc()
    
    print(f"时间: {hour:02d}:{minute:02d}:{second:02d} | 电压: {voltage:.2f}V")
    
    # 低电量保护
    if voltage < 3.2:
        print("电量过低，准备关机...")
        solar.set_power(0)
        break
    
    time.sleep(10)
```

**使用说明：**
- 太阳能电源管理模块通过I2C接口通信，地址为37
- set_power()控制系统电源开关，支持远程开关机
- battery_level()返回实时电池电压，用于电量监测
- read_rtc()读取硬件实时时钟，断电后仍保持时间
- set_rtc()设置硬件时钟，年份自动处理2000年偏移
- set_alarm()设置定时开关机，支持精确到秒的定时控制
- 建议定期监测电池电压，实现低电量保护功能 