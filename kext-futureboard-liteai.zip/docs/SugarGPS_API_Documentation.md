# 方糖GPS模块
简介：用于获取GPS定位信息，支持接收GNSS卫星信号并解析位置、时间、速度等数据
```python
from sugar_gps import SugarGPS
from future import *
import time

# 初始化GPS模块
gps = SugarGPS("uart1")         # uart参数: "uart0"(引脚43,44) / "uart1"(引脚17,18)

while True:
    # 更新GPS数据
    if gps.update():            # 返回值: True(数据更新成功) / False(无信号或数据校验失败)
        
        # 获取GPS时间信息（北京时间）
        hour = gps.getTime(0)    # HMS参数: 0(小时) / 1(分钟) / 2(秒)
        minute = gps.getTime(1)  # 返回值: 对应时间值，失败返回-1
        second = gps.getTime(2)
        
        # 获取GGA数据（位置信息）
        latitude = gps.getDataGGA(2)    # index参数: 常用索引值
        longitude = gps.getDataGGA(4)   # 1: UTC时间, 2: 纬度, 3: 纬度半球(N/S)
        altitude = gps.getDataGGA(9)    # 4: 经度, 5: 经度半球(E/W), 6: 定位质量
        satellites = gps.getDataGGA(7)  # 7: 卫星数量, 8: HDOP精度, 9: 海拔高度
                                        # 返回值: 对应索引的float数值，无数据返回-1
        
        # 获取VTG数据（速度信息）
        course = gps.getDataVTG(1)      # index参数: 常用索引值
        speed_knots = gps.getDataVTG(5) # 1: 真北方位角(度), 3: 磁北方位角(度)
        speed_kmh = gps.getDataVTG(7)   # 5: 地面速度(节), 7: 地面速度(公里/小时)
                                        # 返回值: 对应索引的float数值，无数据返回-1.0
        
        print(f"时间: {hour:02d}:{minute:02d}:{second:02d}")
        print(f"位置: 纬度{latitude}, 经度{longitude}")
        print(f"海拔: {altitude}米, 卫星数: {int(satellites)}")
        print(f"航向: {course}°, 速度: {speed_kmh} km/h")
        
    else:
        print("等待GPS信号...")
    
    time.sleep(1)
```

**使用说明：**
- GPS模块通过UART接口通信，支持uart0和uart1
- 需要在空旷区域使用以获得更好的GPS信号
- update()方法读取并解析$GNGGA和$GNVTG格式的NMEA数据
- getTime()返回的时间已自动转换为北京时间(UTC+8)
- GGA数据包含位置、高度、卫星等信息，索引范围0~14
- VTG数据包含速度、航向等信息，索引范围0~9