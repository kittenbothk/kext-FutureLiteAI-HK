# 方糖TTS语音合成模块
简介：用于文本转语音播报和MP3音频播放功能
```python
from sugar_tts import SugarTTS
from future import *

# 初始化TTS模块
tts = SugarTTS('uart1')        # uart参数: 'uart0'(引脚43,44) / 'uart1'(引脚17,18)
                               # 波特率: 115200

# 切换到TTS语音合成模式
tts.ttsMode()                  # 设置为文本转语音模式

# 播报文本（异步）
tts.playText("你好世界")       # text: 要播报的文本（中文/英文/数字）
                               # 异步播报，不等待完成即返回

# 播报文本（同步等待）
tts.playTextAwait("欢迎使用")  # text: 要播报的文本
                               # 同步播报，等待播报完成后返回
                               # 超过20字符自动分段播报

# 切换到MP3播放模式
tts.mp3Mode()                  # 设置为MP3音频文件播放模式

# 播放控制
tts.play()                     # 开始播放/恢复播放
tts.stop()                     # 停止播放
tts.next()                     # 下一首
tts.prev()                     # 上一首

# 按文件名播放
tts.playName("music")          # name: MP3文件名（可含或不含.mp3扩展名）
                               # 例如: "music" 或 "music.mp3"

# 按ID播放
tts.playId(1)                  # id: 音频文件ID号（int类型）
                               # 播放模块中预存的对应ID音频文件
```

**使用说明：**
- TTS模块通过UART接口通信，支持uart0和uart1
- 支持TTS语音合成和MP3播放两种模式
- TTS模式支持中文、英文、数字、标点符号播报
- MP3模式可播放预存在模块中的音频文件
- 建议单次TTS播报不超过100字符
- 播报时长计算：中文0.26秒/字，英文0.4秒/字 