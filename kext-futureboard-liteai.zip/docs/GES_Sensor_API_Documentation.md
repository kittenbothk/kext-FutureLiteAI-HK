### 气体传感器系列
简介：MQ系列其他传感器
```python
from ges_sensor import *
get_gas_sensor_data(sensorType,pin) #sensorType: 传感器类型，string类型，可选参数：MQ2,MQ3,MQ5,MQ7,MQ135
                                    #pin: 引脚，string类型，可选参数：P1,P2,P3,P4
                                    #返回值：传感器数值
                                    #例如：get_gas_sensor_data('MQ2','P1')
```