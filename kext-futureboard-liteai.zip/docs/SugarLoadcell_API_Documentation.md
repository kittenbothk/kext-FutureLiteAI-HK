# 方糖称重传感器模块
简介：用于测量重量，支持去皮和校准功能，基于NAU7802 ADC芯片
```python
from sugar_loadcell import *
from future import *
import time

# 初始化称重传感器
myScale = SugarLoadcell()           # 通过I2C接口通信，地址0x2A
                                    # 自动加载存储的校准系数

# 初始化传感器
myScale.begin()                     # 返回值: True(初始化成功) / False(初始化失败)
                                    # 重置传感器，设置增益128，采样率80SPS
                                    # 执行模拟前端校准

# 设置去皮重量
myScale.setPeel()                   # 将当前重量设置为去皮基准值
                                    # 用于忽略容器重量，只测量净重

# 获取去皮后重量
net_weight = myScale.getWeightPeel() # 返回值: 去皮后的净重量(整数，单位克)
                                     # 计算公式: 当前重量 - 去皮重量

# 校准传感器
myScale.calibrateScale(100)         # weight参数: 已知标准重量(克)
                                    # 在传感器上放置已知重量进行校准
                                    # 校准系数自动保存到存储芯片

# 典型使用示例 - 电子秤应用
print("请清空称重平台，按回车键设置去皮...")
input()
myScale.setPeel()
print("去皮完成")

print("请放置100克标准砝码，按回车键进行校准...")
input()
myScale.calibrateScale(100)
print("校准完成")

print("请放置待测物品...")
while True:
    weight = myScale.getWeightPeel()
    print(f"净重: {weight} 克")
    
    if weight > 0:
        print("检测到物品")
    elif weight < -5:  # 允许一定误差
        print("请检查传感器连接")
    else:
        print("平台为空")
    
    time.sleep(0.5)
```

**使用说明：**
- 称重传感器通过I2C接口通信，地址为0x2A
- begin()方法必须在使用前调用，完成传感器初始化
- setPeel()用于设置去皮基准，忽略容器重量
- getWeightPeel()返回去皮后的净重量，单位为克
- calibrateScale()需要标准砝码进行校准，提高测量精度
- 校准系数自动保存到存储芯片，断电后仍保持
- 建议在稳定环境下进行校准，避免震动干扰 