# 方糖颜色传感器模块
简介：用于检测RGB颜色值、色调和光照强度，基于BH1745NUC传感器
```python
from sugar_color import *
from future import *
import time

# 初始化颜色传感器
sugarColor = SugarColor()           # 通过I2C接口通信，地址0x38
                                    # 自动配置测量时间160ms，增益1x

# 更新传感器数据
sugarColor.update()                 # 读取并处理传感器数据
                                    # 更新red、green、blue、lm、hue属性值

# 获取RGB颜色值
red_value = sugarColor.red          # 红色分量值(0-255)
green_value = sugarColor.green      # 绿色分量值(0-255)  
blue_value = sugarColor.blue        # 蓝色分量值(0-255)

# 获取色调值
hue_value = sugarColor.hue          # 色调角度(0-360度)
                                    # 0°红色, 120°绿色, 240°蓝色

# 获取光照强度
light_intensity = sugarColor.lm     # 环境光强度(原始数值)
                                    # 数值越大光线越强

# 典型使用示例 - 颜色识别系统
print("颜色传感器初始化完成")

while True:
    # 更新传感器数据
    sugarColor.update()
    
    # 获取颜色数据
    red = sugarColor.red
    green = sugarColor.green
    blue = sugarColor.blue
    hue = sugarColor.hue
    brightness = sugarColor.lm
    
    print(f"RGB值: ({red}, {green}, {blue})")
    print(f"色调: {hue:.1f}°")
    print(f"光强: {brightness}")
    
    # 基于色调进行颜色分类
    if brightness < 100:
        color_name = "环境光线过暗"
    elif 0 <= hue < 30 or 330 <= hue <= 360:
        color_name = "红色"
    elif 30 <= hue < 90:
        color_name = "黄色"
    elif 90 <= hue < 150:
        color_name = "绿色"
    elif 150 <= hue < 210:
        color_name = "青色"
    elif 210 <= hue < 270:
        color_name = "蓝色"
    elif 270 <= hue < 330:
        color_name = "紫色"
    else:
        color_name = "未知颜色"
    
    print(f"识别颜色: {color_name}")
    
    # 基于RGB值的颜色判断
    if red > green and red > blue:
        dominant_color = "红色系"
    elif green > red and green > blue:
        dominant_color = "绿色系"
    elif blue > red and blue > green:
        dominant_color = "蓝色系"
    else:
        dominant_color = "混合色"
    
    print(f"主色调: {dominant_color}")
    print("-" * 30)
    
    time.sleep(1)
```

**使用说明：**
- 颜色传感器通过I2C接口通信，地址为0x38
- update()方法必须调用以更新传感器数据
- red、green、blue属性返回0-255范围的RGB值
- hue属性返回0-360度的色调角度值
- lm属性返回原始光强数值，用于环境光检测
- 传感器内置自动增益和颜色校正算法
- 建议在稳定光源下使用以获得准确的颜色检测 