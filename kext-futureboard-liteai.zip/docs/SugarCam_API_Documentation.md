# 方糖摄像头模块
简介：支持拍照、录像、二维码识别、OCR文字识别等功能，提供有线UART和无线WiFi两种连接方式
```python
from sugar_cam import *
from screen import Screen
from future import *
import time

# 有线连接版本 - SugarCam
sugarCam = SugarCam('uart0')        # uart参数: 'uart0' / 'uart1'
                                    # 通过UART接口通信，波特率115200

# 按键状态检测
button_pressed = sugarCam.buttonState('BTNA')  # button参数: 'BTNA' / 'BTNB'
                                               # 返回值: True(按下) / False(未按下) / None(无数据)

# LED颜色控制
sugarCam.setColor((0, 168, 0), (0, 168, 0))   # color1, color2: RGB颜色元组
                                               # 分别控制两个LED的颜色

sugarCam.setAllColor((0, 168, 0))              # color1: RGB颜色元组
                                               # 设置所有LED为相同颜色

# 拍照功能
sugarCam.takePicture('kittenbot.jpg')         # filename: 保存的图片文件名
                                               # 拍摄照片并保存到指定文件

# 音频播放
sugarCam.playWav('kittenblock.mp3')           # wav: 音频文件名
                                               # 播放指定的音频文件

# 二维码识别
qr_result = sugarCam.getQRcode()               # 返回值: 二维码内容字符串 / None(未识别到)
                                               # 识别画面中的二维码

# 获取IP地址
ip_address = sugarCam.ipAddr()                 # timeout: 超时时间(默认5000ms)
                                               # 返回值: IP地址字符串 / 0(超时)

# OCR文字识别
ocr_result = sugarCam.ocr()                    # timeout: 超时时间(默认5000ms)
                                               # 返回值: 识别的文字内容 / 0(超时或失败)

# 无线连接版本 - SugarCamWireless
screens = Screen()                             # 创建屏幕对象用于显示
camCB = SugarCamWireless('192.168.0.233', secret='miao')  # host: 摄像头IP地址
                                                          # port: 端口号(默认9233)
                                                          # secret: 连接密钥

# 无线视频流显示
camCB.displayFrameJpg(screens)                 # screen: Screen对象
                                               # 获取并显示一帧JPEG图像
screens.refresh()                              # 刷新屏幕显示

# 典型使用示例 - 智能监控系统
print("初始化方糖摄像头...")

# 设置LED为绿色表示正常工作
sugarCam.setAllColor((0, 255, 0))

while True:
    # 检测按键A
    if sugarCam.buttonState('BTNA'):
        print("按键A被按下，开始拍照...")
        
        # 设置LED为蓝色表示拍照中
        sugarCam.setAllColor((0, 0, 255))
        
        # 拍照并播放提示音
        sugarCam.takePicture(f'photo_{int(time.time())}.jpg')
        sugarCam.playWav('camera_sound.mp3')
        
        # 恢复绿色
        sugarCam.setAllColor((0, 255, 0))
    
    # 检测按键B
    if sugarCam.buttonState('BTNB'):
        print("按键B被按下，开始二维码扫描...")
        
        # 设置LED为黄色表示扫描中
        sugarCam.setAllColor((255, 255, 0))
        
        qr_code = sugarCam.getQRcode()
        if qr_code:
            print(f"识别到二维码: {qr_code}")
            sugarCam.playWav('success.mp3')
        else:
            print("未识别到二维码")
            sugarCam.playWav('error.mp3')
        
        # 恢复绿色
        sugarCam.setAllColor((0, 255, 0))
    
    # OCR文字识别示例
    ocr_text = sugarCam.ocr(timeout=3000)
    if ocr_text and ocr_text != 0:
        print(f"识别到文字: {ocr_text}")
    
    time.sleep(0.1)

# 无线摄像头实时显示示例
print("启动无线摄像头实时显示...")
while True:
    try:
        camCB.displayFrameJpg(screens)
        screens.refresh()
    except Exception as e:
        print(f"显示错误: {e}")
        time.sleep(1)
```

**使用说明：**
- **有线版本(SugarCam)**：通过UART接口连接，支持完整的摄像头功能
- **无线版本(SugarCamWireless)**：通过WiFi连接，主要用于实时视频流显示
- buttonState()方法检测摄像头上的物理按键状态
- setColor()和setAllColor()控制摄像头LED指示灯
- takePicture()拍摄照片并保存到摄像头存储器
- playWav()播放摄像头内置或存储的音频文件
- getQRcode()实时识别画面中的二维码内容
- ocr()识别画面中的文字内容，支持中英文
- ipAddr()获取摄像头的网络IP地址
- displayFrameJpg()获取并显示实时视频帧，需配合Screen使用 