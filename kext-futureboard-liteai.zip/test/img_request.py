# from board import *
# from koi2 import KOI2
# koi = KOI2("uart0")
# # f = open("face.jpg", "rb")
# # fb.loadjpg(f, 0, 0, True)
# while True:
#     input("press enter to get image")
#     jpg = koi.getImg()[0]
#     fb.loadjpg(jpg, 0, 0, True)
#     tft.show()
import ujson
import urequests
import ubinascii
import network
import gc
from board import *
from koi2 import KOI2
import time

koi = KOI2("uart0")

sta = network.WLAN(network.STA_IF)
sta.active(True)
sta.connect("Kittenbot", "kittenbot428")
while not sta.isconnected():
    time.sleep(0.2)
time.sleep(1)
sta.ifconfig()

url = "https://kzone.kittenbot.cn/api/v1/image/face"
headers = {
    "Authorization": "WLVFZEY4",
    "Content-Type": "application/json",
}
# f = open("face.jpg", "rb")
# img_b64 = ubinascii.b2a_base64(f.read()).decode().strip()
# f.close()
scale_down = True
while True:
    input("press enter to get image")
    jpg = koi.getJpgBuf(clear_uart=True, display=True)
    if jpg is None:
        print("jpg is None")
        gc.collect()
        continue
    img_b64 = ubinascii.b2a_base64(jpg).decode().strip()
    payload = {"reqUrl": "detect", "img": img_b64}
    r = urequests.post(url, data=ujson.dumps(payload), headers=headers, timeout=15)

    try:
        data = r.json()
    except Exception as e:
        print("error: ", e)
        try:
            print("r.text(head500): ", r.text[:500])
        except Exception:
            pass
        gc.collect()
        continue
    finally:
        r.close()



    # f = open("face.jpg", "rb")
    # fb.loadjpg(f, 0, 0)
    # f.close()
    if not scale_down:
        fb.loadjpg(jpg, 0, 0, False)
    

    result = data.get("result", {})
    face_list = []
    if result is not None:
        if "result" in result:
            result = result.get("result", {})

        face_list = result.get("face_list", [])

        # 颜色定义
        COLOR_BOX = 0x0000FF
        COLOR_LANDMARK4 = 0x00FF00
        COLOR_LANDMARK72 = 0xFFFF00
        COLOR_LANDMARK150 = 0x00FFFF
        COLOR_TEXT = 0xFFFFFF

        for idx, face in enumerate(face_list):
            location = face.get("location", {})
            location_left = int(location.get("left", 0))
            location_top = int(location.get("top", 0))
            location_width = int(location.get("width", 0))
            location_height = int(location.get("height", 0))
            if scale_down:
                location_left = location_left // 2
                location_top = location_top // 2
                location_width = location_width // 2
                location_height = location_height // 2

            # 人脸框
            fb.rect(location_left, location_top, location_width, location_height, COLOR_BOX, 0)
            fb.text(str(idx + 1), location_left, max(location_top - 10, 0), COLOR_TEXT, 1)

            # 4个关键点（大一点，便于观察）
            for p in face.get("landmark", []):
                x = int(p.get("x", 0))
                y = int(p.get("y", 0))
                if scale_down:
                    x = x // 2
                    y = y // 2
                fb.circle(x, y, 2, COLOR_LANDMARK4, True)

            # 72关键点
            for p in face.get("landmark72", []):
                x = int(p.get("x", 0))
                y = int(p.get("y", 0))
                if scale_down:
                    x = x // 2
                    y = y // 2
                fb.pixel(x, y, COLOR_LANDMARK72)

            # 150关键点（字典结构）
            landmark150 = face.get("landmark150", {})
            if isinstance(landmark150, dict):
                for _, p in landmark150.items():
                    if isinstance(p, dict):
                        x = int(p.get("x", 0))
                        y = int(p.get("y", 0))
                        if scale_down:
                            x = x // 2
                            y = y // 2
                        fb.pixel(x, y, COLOR_LANDMARK150)

    tft.show()
    # 结果很大（含 landmark150）时及时回收，减少后续串口/网络超时
    del data, result, face_list, payload, img_b64, jpg
    gc.collect()
